
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("../data/cancelamentos.csv")

sns.countplot(x="cancelou",data=df)
plt.title("Distribuição de Cancelamento")
plt.savefig("../reports/churn_distribution.png")

sns.histplot(df["total_gasto"],bins=30)
plt.title("Distribuição de Gastos")
plt.savefig("../reports/spending_distribution.png")
