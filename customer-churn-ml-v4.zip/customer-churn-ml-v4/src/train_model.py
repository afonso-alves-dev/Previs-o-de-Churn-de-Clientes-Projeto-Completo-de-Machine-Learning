
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from data_loader import load_data
from features import prepare_features

df = load_data()
X,y = prepare_features(df)

X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=42)

model = RandomForestClassifier(n_estimators=300)
model.fit(X_train,y_train)

pred = model.predict(X_test)

print(classification_report(y_test,pred))

joblib.dump(model,"../models/churn_model.pkl")
