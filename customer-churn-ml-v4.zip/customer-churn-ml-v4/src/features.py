
def prepare_features(df):
    X = df.drop(columns=["cancelou","CustomerID"], errors="ignore")
    y = df["cancelou"]
    return X,y
