
# Customer Churn ML Project v4

Projeto completo de Data Science com:

- EDA
- Treinamento de modelo ML
- API de previsão (FastAPI)
- Dashboard interativo (Streamlit)

## Treinar modelo

python src/train_model.py

## Rodar API

uvicorn api.app:app --reload

## Rodar dashboard

streamlit run dashboard/app.py
