
import streamlit as st
import pandas as pd
import joblib

st.title("Customer Churn Prediction Dashboard")

model = joblib.load("../models/churn_model.pkl")

st.header("Inserir dados do cliente")

idade = st.number_input("Idade",18,100,30)
total_gasto = st.number_input("Total gasto",0.0,10000.0,500.0)
meses = st.number_input("Meses desde última interação",0,60,12)

if st.button("Prever cancelamento"):

    data = pd.DataFrame([{
        "idade":idade,
        "total_gasto":total_gasto,
        "meses_ultima_interacao":meses
    }])

    pred = model.predict(data)[0]

    if pred==1:
        st.error("Cliente com risco de cancelamento")
    else:
        st.success("Cliente com baixo risco")
