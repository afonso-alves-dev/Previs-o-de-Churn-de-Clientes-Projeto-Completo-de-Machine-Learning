
from fastapi import FastAPI
import joblib
import pandas as pd

app = FastAPI(title="Customer Churn Prediction API")

model = joblib.load("../models/churn_model.pkl")

@app.get("/")
def root():
    return {"message":"Churn prediction API running"}

@app.post("/predict")
def predict(data: dict):
    df = pd.DataFrame([data])
    pred = model.predict(df)[0]
    return {"churn_prediction": int(pred)}
